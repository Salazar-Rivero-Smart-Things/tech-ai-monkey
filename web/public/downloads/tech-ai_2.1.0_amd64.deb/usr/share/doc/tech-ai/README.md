# Tech AI monkey CLI

Install:  sudo dpkg -i tech-ai_2.1.0_amd64.deb
Sign in:  tech-ai login
Ask:      tech-ai ask "hello"
Chat:     tech-ai chat

Open a terminal and run "tech-ai". On the first run it offers to sign you in
through your browser, then drops you straight into the chat.

On a desktop Linux the application menu also gets a "Tech AI monkey" entry
(right-click for "Sign in"). It opens a terminal and starts the same flow, and
keeps the window open if something goes wrong.

Docs: https://tech-ai.tech/download
